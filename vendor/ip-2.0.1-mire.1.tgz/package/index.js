'use strict';
// Remplaçant pour Mire : adresse IPv4 (4 octets) ou IPv6 (16 octets) en texte, comme ip.toString d'origine.
function toString(buff, offset = 0, length) {
  offset = ~~offset;
  length = length || buff.length - offset;
  if (length === 4) return Array.from(buff.subarray(offset, offset + 4)).join('.');
  if (length === 16) {
    const parts = [];
    for (let i = 0; i < 16; i += 2) parts.push(((buff[offset + i] << 8) | buff[offset + i + 1]).toString(16));
    return parts.join(':').replace(/(^|:)0(:0)*:0(:|$)/, '$1::$3').replace(/:{3,4}/, '::');
  }
  throw new Error('Adresse IP binaire invalide');
}
module.exports = { toString };
module.exports.default = module.exports;
