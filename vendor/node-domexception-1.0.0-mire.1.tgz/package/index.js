'use strict';
// Remplaçant pour Mire : DOMException fait partie de Node depuis la version 17.
module.exports = globalThis.DOMException;
