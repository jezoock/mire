// Remplaçant pour Mire : pas de WebRTC dans le processus principal (simple-peer le détecte : WEBRTC_SUPPORT = false).
export const RTCPeerConnection = undefined;
export const RTCSessionDescription = undefined;
export const RTCIceCandidate = undefined;
export default {};
