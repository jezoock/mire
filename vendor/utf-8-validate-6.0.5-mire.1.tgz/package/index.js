'use strict';
// Remplaçant pour Mire : pas de module natif. Le chargement échoue volontairement,
// comme si le module était absent ; le paquet qui l'utilise prend alors son chemin JavaScript.
throw Object.assign(new Error('utf-8-validate : module natif non installé (remplaçant Mire)'), { code: 'MODULE_NOT_FOUND' });
